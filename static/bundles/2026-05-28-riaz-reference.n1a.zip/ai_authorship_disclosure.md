# AI Authorship Disclosure

No human author beyond the patient and supervising clinician.

| Expert | Role |
| - | - |
| Iain | Wave 1 retrieval |
| Aviv | Wave 3 analysis |
| Henry | audit |
