# Methods

This is a single-subject (N=1) design demonstration [PMID:29033130].
