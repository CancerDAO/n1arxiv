# Ethics Declaration

This is a methodology reference case using public Riaz et al. data. No real patient is involved.
