> [REFERENCE CASE — PUBLIC DATA, NOT THIS PATIENT]

# Methodology Reference Case: Riaz et al. melanoma cohort

[BACKGROUND] This is a methodology demonstration using the
publicly released Riaz et al. (2017) anti-PD-1 melanoma cohort
[PMID:29033130]. It is NOT a real patient case.

## Methods

This is a single-subject (N=1) design demonstration. Each Wave 1
retrieval was anchored to the Riaz public dataset [PMID:29033130].

## Results

Response was associated with mutational burden [PMID:29033130].