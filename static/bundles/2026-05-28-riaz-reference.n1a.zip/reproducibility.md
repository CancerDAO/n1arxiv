# Reproducibility

## Data sources

- Riaz et al. melanoma cohort, tier: public [PMID:29033130]

## Software

- opl-cancer v2.4.0
